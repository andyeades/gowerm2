<?php

namespace Punchout2go\Purchaseorder\Block\Adminhtml\Sales\Order\View\Tab;

class Info extends  \Magento\Sales\Block\Adminhtml\Order\View\Tab\Info
{



}